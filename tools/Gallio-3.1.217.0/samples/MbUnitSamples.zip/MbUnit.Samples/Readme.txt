MbUnit Samples
==============

This project contains sample code to help you get up and running with MbUnit v3.

Each sample test fixture contains embedded documentation in the form of XML
doc comments on the class and its methods.  Please refer to the MbUnit API
documentation for more information.

(Hint: If you installed the Visual Studio help documentation for MbUnit, then you
       can easily navigate to the documentation of any MbUnit API method
       within the IDE by hitting F1!)

﻿using System;
using System.Collections.Generic;
$if$ ($targetframeworkversion$ == 3.5)using System.Linq;
$endif$using System.Text;
using Gallio.Framework;
using MbUnit.Framework;
using MbUnit.Framework.ContractVerifiers;

namespace $rootnamespace$
{
    [TestFixture]
    public class $safeitemrootname$
    {
        [Test]
        public void Test()
        {
            //
            // TODO: Add test logic here
            //
        }
    }
}

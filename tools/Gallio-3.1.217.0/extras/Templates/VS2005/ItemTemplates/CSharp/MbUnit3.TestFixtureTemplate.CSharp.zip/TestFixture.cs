﻿using System;
using System.Collections.Generic;
using System.Text;
using Gallio.Framework;
using MbUnit.Framework;
using MbUnit.Framework.ContractVerifiers;

namespace $rootnamespace$
{
    [TestFixture]
    public class $safeitemrootname$
    {
        [Test]
        public void Test()
        {
            //
            // TODO: Add test logic here
            //
        }
    }
}

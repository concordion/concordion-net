﻿Imports Gallio.Framework
Imports MbUnit.Framework
Imports MbUnit.Framework.ContractVerifiers

<TestFixture> _
Public Class $safeitemname$
    <Test()> _
    Public Sub Test()
        ' TODO: Add test logic here
    End Sub
End Class

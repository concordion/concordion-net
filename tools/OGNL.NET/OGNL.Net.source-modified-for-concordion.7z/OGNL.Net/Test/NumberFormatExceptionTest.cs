using System ;

using ognl ;

using org.ognl.test.objects ;
using org.ognl.test.util ;
//--------------------------------------------------------------------------
//  Copyright (c) 2004, Drew Davidson and Luke Blanshard
//  All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are
//  met:
//
//  Redistributions of source code must retain the above copyright notice,
//  this list of conditions and the following disclaimer.
//  Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the distribution.
//  Neither the name of the Drew Davidson nor the names of its contributors
//  may be used to endorse or promote products derived from this software
//  without specific prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
//  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
//  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
//  OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
//  AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
//  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
//  THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
//  DAMAGE.
//--------------------------------------------------------------------------
namespace org.ognl.test
{
	public class NumberFormatExceptionTest : OgnlTestCase
	{
		private static Simple           SIMPLE = new Simple();

		private static object[][]       TESTS = {
													// NumberFormatException handling (default is to throw NumberFormatException on bad string conversions)
													new object [] { SIMPLE, "FloatValue", (0f), (10f), (10f) },    /* set float to 10.0f */
													new object [] { SIMPLE, "FloatValue", (10f), "x10x", typeof (OgnlException) },      /* set float to invalid format string, should yield OgnlException */

													new object [] { SIMPLE, "IntValue", (0), (34), (34) },   /* set int to 34 */
													new object [] { SIMPLE, "IntValue", (34), "foobar", typeof (OgnlException) },     /* set int to invalid format string, should yield OgnlException */
													new object [] { SIMPLE, "IntValue", (34), "", typeof (OgnlException) },           /* set int to empty string, should yield 0gnlException */
													new object [] { SIMPLE, "IntValue", (34), "       \t", typeof (OgnlException) },  /* set int to whitespace-only string, should yield 0gnlException */
													new object [] { SIMPLE, "IntValue", (34), "       \t1234\t\t", (1234) },    /* set int to whitespace-laden valid string, should yield 1234 */

													//										{ SIMPLE, "bigIntValue", BigInteger.valueOf(0), BigInteger.valueOf(34), BigInteger.valueOf(34) },   /* set bigint to 34 */
													//										{ SIMPLE, "bigIntValue", BigInteger.valueOf(34), null, null },              /* set bigint to null string, should yield 0 */
													// new object [] { SIMPLE, "BigIntValue", null, "", typeof (OgnlException) },                   /* set bigint to empty string, should yield 0gnlException */
													// new object [] { SIMPLE, "BigIntValue", null, "foobar", typeof (OgnlException) },             /* set bigint to invalid format string, should yield OgnlException */
                    
													new object [] { SIMPLE, "BigDecValue", (decimal)(0.0), (decimal)(34.55), (decimal)(34.55) },   /* set bigdec to 34.55 */
													// new object [] { SIMPLE, "BigDecValue", (decimal)(34.55), null, null },               /* set bigdec to null string, should yield 0.0 */
													// new object [] { SIMPLE, "BigDecValue", null, "", null} ,// typeof (OgnlException) },                   /* set bigdec to empty string, should yield 0gnlException */
													// new object [] { SIMPLE, "BigDecValue", null, "foobar", null} , // typeof (OgnlException) },             /* set bigdec to invalid format string, should yield OgnlException */
		};

		/*===================================================================
			Public static methods
		  ===================================================================*/
		public override TestSuite suite()
		{
			TestSuite       result = new TestSuite();

			for (int i = 0; i < TESTS.Length; i++) 
			{
				if (TESTS[i].Length == 3) 
				{
					result.addTest(new NumberFormatExceptionTest((string)TESTS[i][1], TESTS[i][0], (string)TESTS[i][1], TESTS[i][2]));
				} 
				else 
				{
					if (TESTS[i].Length == 4) 
					{
						result.addTest(new NumberFormatExceptionTest((string)TESTS[i][1], TESTS[i][0], (string)TESTS[i][1], TESTS[i][2], TESTS[i][3]));
					} 
					else 
					{
						if (TESTS[i].Length == 5) 
						{
							result.addTest(new NumberFormatExceptionTest((string)TESTS[i][1], TESTS[i][0], (string)TESTS[i][1], TESTS[i][2], TESTS[i][3], TESTS[i][4]));
						} 
						else 
						{
							throw new Exception("don't understand TEST format");
						}
					}
				}
			}
			return result;
		}

		/*===================================================================
			Constructors
		  ===================================================================*/
		public NumberFormatExceptionTest()
		{
	
		}

		public NumberFormatExceptionTest(string name): base(name)
		{
	    
		}

		public NumberFormatExceptionTest(string name, object root, string expressionString, object expectedResult, object setValue, object expectedAfterSetResult)
			:base(name, root, expressionString, expectedResult, setValue, expectedAfterSetResult)
		{
        
		}

		public NumberFormatExceptionTest(string name, object root, string expressionString, object expectedResult, object setValue)
			: base(name, root, expressionString, expectedResult, setValue)
		{
        
		}

		public NumberFormatExceptionTest(string name, object root, string expressionString, object expectedResult)
			: base(name, root, expressionString, expectedResult)
		{
        
		}
	}
}
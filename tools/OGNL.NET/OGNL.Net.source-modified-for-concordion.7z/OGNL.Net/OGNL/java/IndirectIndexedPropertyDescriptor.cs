using System;
using System.Reflection ;

namespace java
{
	/// <summary>
	/// IndirectIndexedPropertyDescriptor ��ժҪ˵����
	/// </summary>
	public class IndirectIndexedPropertyDescriptor : IndexedPropertyDescriptor
	{
		public IndirectIndexedPropertyDescriptor (PropertyInfo p) : base (p)
		{
		}
	}
}
